let Radius = prompt ('enter Radius')
let Area = Math.PI*Math.pow(Radius,2)
alert ( Area)
